from .LazyDecisionTree import LazyDecisionTree, Node
